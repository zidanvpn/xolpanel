from regis import *

@bot.on(events.NewMessage(pattern=r"(?:.regis|/regis|/sayang|/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" CHECK","cekip")],
        [Button.inline(" SSH MANAJER ","ssh")],
        [Button.inline(" VMESS MANAJER ","vmess"),
         Button.inline(" VLESS MANAJER ","vless")],
        [Button.inline(" TROJAN MANAJER ","trojan"),
         Button.inline(" CHANGE ALL LIMIT ","change-limit-all")],
        [Button.inline(" CHANGE ALL QOUTA ","change-all-qouta"),
         Button.inline(" POINTING DOMAIN ","domain")],
        [Button.inline(" CHECK VPS INFO ", "info"),
         Button.inline(" OTHER SETTING ", "setting")],
        [Button.url("ORDER🐳", "https://t.me/AndyYudaKLMPK"),
         Button.url("GROUP🐬", "https://chat.whatsapp.com/IMwXEDPHxatHBg9bOk7iME")]
    ]

    try:
        sender = await event.get_sender()
        sh = f"awk -F: '$3 >= 1000 && $1 != \"nobody\" {{print $1}}' /etc/passwd | wc -l"
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f"grep -E \"^### \" \"/etc/xray/config.json\" | sort -u | wc -l"
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        vl = f"grep -E \"^#& \" \"/etc/xray/config.json\" | sort -u | wc -l"
        vls = subprocess.check_output(vl, shell=True).decode("ascii")
        tr = f"grep -E \"^#! \" \"/etc/xray/config.json\" | sort -u | wc -l"
        trj = subprocess.check_output(tr, shell=True).decode("ascii")
        sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        ipvps = f" curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        citsy = f" cat /etc/xray/city"
        city = subprocess.check_output(citsy, shell=True).decode("ascii")

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**☘️ KLMPK Autoscript Premium ☘️**
━━━━━━━━━━━━━━━━━━━━━━━ 
Halo Tuan {sender.first_name}
Selamat Datang Di Layanan Script premium

**» OS     :** `{namaos.strip().replace('"','')}`
**» CITY :** `{city.strip()}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ipsaya.strip()}`
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{ssh.strip()}` __account__
**» 🎭XRAY VMESS  :** `{vms.strip()}` __account__
**» 🗼XRAY VLESS  :** `{vls.strip()}` __account__
**» 🎯XRAY TROJAN :** `{trj.strip()}` __account__

List Harga Script :** 
🔰**1 BULAN 10k**
🔰**2 BULAN 20k**
🔰**3 BULAN 30K**
🔰**LIFE TIME 1IP 55K**

Note:
**- Anda harus memiliki akses Terlebih Dahulu**
**- Hubungi Admin Agar Anda Mempunyai Akses**.
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Order :** @Andyyuda
**» Total Pelanggan :** `{ssh.strip()}`
"""
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)
    except Exception as e:
        error_msg = f"Terjadi kesalahan: {str(e)}"
        await event.reply(error_msg)
